// Динамическое отображение полей формы
document.getElementById('service')?.addEventListener('change', function() {
    const service = this.value;
    const formFields = document.getElementById('formFields');
    formFields.innerHTML = '';

    if (service === 'vehicle_registration') {
        formFields.innerHTML = `
            <div class="form-group">
                <label for="vin">VIN номер:</label>
                <input type="text" class="form-control" id="vin" name="vin" required maxlength="16">
            </div>
            <div class="form-group">
                <label for="brand">Марка автомобиля:</label>
                <input type="text" class="form-control" id="brand" name="brand" required>
            </div>
            <div class="form-group">
                <label for="model">Модель автомобиля:</label>
                <input type="text" class="form-control" id="model" name="model" required>
            </div>
            <div class="form-group">
                <label for="year">Год выпуска:</label>
                <input type="number" class="form-control" id="year" name="year" required>
            </div>
        `;
    } else if (service === 'license_issuance') {
        formFields.innerHTML = `
            <div class="form-group">
                <label for="name">ФИО:</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="dob">Дата рождения:</label>
                <input type="date" class="form-control" id="dob" name="dob" required>
            </div>
            <div class="form-group">
                <label for="license_number">Номер водительского удостоверения:</label>
                <input type="text" class="form-control" id="license_number" name="license_number" required>
            </div>
        `;
    } else if (service === 'fine_check') {
        formFields.innerHTML = `
            <div class="form-group">
                <label for="license_number">Номер водительского удостоверения:</label>
                <input type="text" class="form-control" id="license_number" name="license_number" required>
            </div>
        `;
    }
});

// Отправка формы
document.getElementById('serviceForm')?.addEventListener('submit', async function(event) {
    event.preventDefault();

    const service = document.getElementById('service').value;
    const formData = new FormData(this);

    let data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });

    try {
        // Проверка длины VIN-номера для регистрации транспортного средства
        if (service === 'vehicle_registration' && data.vin.length !== 16) {
            alert('VIN-номер должен содержать ровно 16 символов.');
            return;
        }

        const response = await fetch('/api/services', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ service, ...data }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Ошибка при отправке заявки');
        }

        $('#successModal').modal('show');
    } catch (error) {
        console.error('Ошибка:', error);
        alert(error.message || 'Произошла ошибка при отправке заявки.');
    }
});

// Обработка формы регистрации
document.getElementById('registerForm')?.addEventListener('submit', async function(event) {
    event.preventDefault();

    const formData = new FormData(this);
    const data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });

    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Ошибка при регистрации');
        }

        alert('Регистрация прошла успешно!');
        window.location.href = 'login.html'; // Перенаправление на страницу входа
    } catch (error) {
        console.error('Ошибка:', error);
        alert(error.message || 'Произошла ошибка при регистрации.');
    }
});

// Обработка формы входа
document.getElementById('loginForm')?.addEventListener('submit', async function(event) {
    event.preventDefault();

    const formData = new FormData(this);
    const data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Ошибка при входе');
        }

        const result = await response.json();
        alert(result.message);
        window.location.href = 'index.html'; // Перенаправление на главную страницу
    } catch (error) {
        console.error('Ошибка:', error);
        alert(error.message || 'Произошла ошибка при входе.');
    }
});

// Функция для выхода
async function logout() {
    try {
        const response = await fetch('/api/logout', {
            method: 'GET',
        });

        if (response.redirected) {
            window.location.href = response.url; // Перенаправляем на страницу логина
        }
    } catch (error) {
        console.error('Ошибка:', error);
        alert('Произошла ошибка при выходе из системы.');
    }
}

// Проверка авторизации при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    if (!window.location.pathname.includes('login.html') && !window.location.pathname.includes('register.html')) {
        fetch('/api/check-auth')
            .then(response => response.json())
            .then(data => {
                if (!data.authenticated) {
                    window.location.href = 'login.html'; // Перенаправляем на страницу логина
                }
            })
            .catch(error => {
                console.error('Ошибка:', error);
                window.location.href = 'login.html';
            });
    }

    if (window.location.pathname.includes('news.html')) {
        fetchNews();
    }
});

// Функция для загрузки новостей
async function fetchNews() {
    try {
        const response = await fetch('/api/news');
        if (!response.ok) {
            throw new Error('Сеть ответила с ошибкой: ' + response.status);
        }
        const news = await response.json();
        const newsContainer = document.getElementById('news-container');
        newsContainer.innerHTML = '';

        news.forEach(item => {
            const col = document.createElement('div');
            col.className = 'col-md-6 col-lg-4 mb-4';

            const card = document.createElement('div');
            card.className = 'news-card';

            card.innerHTML = `
                <h3>${item.title}</h3>
                <p>${item.content}</p>
                <small>Дата публикации: ${item.date}</small>
            `;

            col.appendChild(card);
            newsContainer.appendChild(col);
        });
    } catch (error) {
        console.error('Ошибка при загрузке новостей:', error);
        const newsContainer = document.getElementById('news-container');
        newsContainer.innerHTML = '<p class="text-danger">Не удалось загрузить новости. Пожалуйста, попробуйте позже.</p>';
    }
}