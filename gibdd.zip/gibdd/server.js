const express = require('express');
const { Client } = require('pg');
const cors = require('cors');
const path = require('path');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');

const app = express();
const port = 3000;

app.use(
  helmet.contentSecurityPolicy({
    useDefaults: true,
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: [
        "'self'",
        "https://code.jquery.com",
        "https://cdn.jsdelivr.net",
        "https://stackpath.bootstrapcdn.com" 
      ],
      styleSrc: [
        "'self'",
        "https://stackpath.bootstrapcdn.com",
        "'unsafe-inline'"
      ],
      connectSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
    }
  })
);
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // для HTTPS установите secure: true
}));

// Подключение к базе данных PostgreSQL
const client = new Client({
  user: 'postgres',
  host: 'localhost',
  database: 'gibdd',
  password: '22081921',
  port: 5432,
});
client.connect();

// Middleware проверки авторизации
function isAuthenticated(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    res.redirect('/login.html');
  }
}

// Разрешаем доступ к /login.html, /register.html и /api/* без авторизации
app.use((req, res, next) => {
  if (
    req.path === '/login.html' ||
    req.path === '/register.html' ||
    req.path.startsWith('/api/')
  ) {
    next();
  } else {
    isAuthenticated(req, res, next);
  }
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Эндпоинт для получения новостей
app.get('/api/news', (req, res) => {
  const news = [
    {
      id: 1,
      title: 'Новая инициатива по безопасности на дорогах',
      content: 'ГИБДД запускает новую программу по повышению безопасности на дорогах...',
      date: '2023-10-01',
    },
    {
      id: 2,
      title: 'Обновление системы штрафов',
      content: 'С 1 ноября вступают в силу новые правила начисления штрафов...',
      date: '2023-10-15',
    },
    {
      id: 3,
      title: 'Новые камеры на дорогах',
      content: 'В городе установлены новые камеры для контроля скорости...',
      date: '2023-10-20',
    },
  ];
  res.json(news);
});

// Эндпоинт для регистрации пользователей
app.post('/api/register', async (req, res) => {
  const { name, email, city, country, password } = req.body;
  try {
    const existingUser  = await client.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );
    if (existingUser .rows.length > 0) {
      return res.status(400).json({ error: 'Пользователь с таким email уже существует.' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    await client.query(
      'INSERT INTO users (name, email, city, country, password) VALUES ($1, $2, $3, $4, $5)',
      [name, email, city, country, hashedPassword]
    );
    res.status(201).json({ message: 'Пользователь успешно зарегистрирован.' });
  } catch (error) {
    console.error('Ошибка:', error);
    res.status(500).json({ error: 'Ошибка при регистрации пользователя.' });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await client.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );
    if (result.rows.length === 0) {
      return res.status(400).json({ error: 'Неверный email или пароль.' });
    } // Close the if statement here
    const user = result.rows[0];
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ error: 'Неверный email или пароль.' });
    }
    req.session.user = { id: user.id, name: user.name, email: user.email };
    res.status(200).json({ message: 'Авторизация успешна.', user: req.session.user });
  } catch (error) {
    console.error('Ошибка:', error);
    res.status(500).json({ error: 'Ошибка при авторизации.' });
  }
});

// Эндпоинт для выхода
app.get('/api/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Ошибка при выходе из системы.' });
    }
    res.redirect('/login.html');
  });
});

// Эндпоинт для проверки авторизации
app.get('/api/check-auth', (req, res) => {
  res.json({ authenticated: !!req.session.user });
});

// Эндпоинт для обработки сервисных заявок
app.post('/api/services', async (req, res) => {
  const { service, vin, brand, model, year, registration_number, owner_id } = req.body;
  try {
    if (service === 'vehicle_registration') {
      if (vin.length !== 16) {
        return res.status(400).json({ error: 'VIN-номер должен содержать ровно 16 символов.' });
      }
      await client.query(
        'INSERT INTO car (vin, brand, model, year, color, registration_number, owner_id) VALUES ($1, $2, $3, $4, $5, $6, $7)',
        [vin, brand, model, year, req.body.color, registration_number, owner_id]
      );
      return res.json({ message: 'Заявка на регистрацию транспортного средства принята.' });
    } else if (service === 'license_issuance') {
      // Логика для выдачи водительских удостоверений
      return res.json({ message: 'Заявка на выдачу водительского удостоверения принята.' });
    } else if (service === 'fine_check') {
      // Логика для проверки штрафов
      return res.json({ message: 'Запрос на проверку штрафов принят.' });
    } else {
      return res.status(400).json({ error: 'Неизвестная услуга.' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Ошибка при обработке запроса.' });
  }
});

// Обработка несуществующих маршрутов
app.use((req, res) => {
  res.status(404).send('Страница не найдена');
});

app.listen(port, () => {
  console.log(`Сервер запущен на http://localhost:${port}`);
});